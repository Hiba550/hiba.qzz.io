execute if score #value ldc.input matches 6..40 run scoreboard players operation #delay ldc.config = #value ldc.input
execute if score #value ldc.input matches 6..40 run tellraw @s [{"text":"LeaveDecay start delay set to ","color":"green"},{"score":{"name":"#delay","objective":"ldc.config"}},{"text":" ticks.","color":"green"}]
execute unless score #value ldc.input matches 6..40 run tellraw @s {"text":"Delay must be between 6 and 40 ticks.","color":"red"}
