execute if score #value ldc.input matches 32..4096 run scoreboard players operation #max ldc.config = #value ldc.input
execute if score #value ldc.input matches 32..4096 run tellraw @s [{"text":"LeaveDecay queue limit set to ","color":"green"},{"score":{"name":"#max","objective":"ldc.config"}},{"text":" nodes.","color":"green"}]
execute unless score #value ldc.input matches 32..4096 run tellraw @s {"text":"Queue limit must be between 32 and 4096.","color":"red"}
