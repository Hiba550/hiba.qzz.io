execute if score #value ldc.input matches 1..16 run scoreboard players operation #budget ldc.config = #value ldc.input
execute if score #value ldc.input matches 1..16 run tellraw @s [{"text":"LeaveDecay budget set to ","color":"green"},{"score":{"name":"#budget","objective":"ldc.config"}},{"text":" queue nodes per tick.","color":"green"}]
execute unless score #value ldc.input matches 1..16 run tellraw @s {"text":"Budget must be between 1 and 16.","color":"red"}
