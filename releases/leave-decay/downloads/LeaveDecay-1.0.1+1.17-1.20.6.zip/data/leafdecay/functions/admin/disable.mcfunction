scoreboard players set #enabled ldc.config 0
tellraw @s {"text":"LeaveDecay paused. Pending cleanup is preserved.","color":"yellow"}
