scoreboard players set #enabled ldc.config 1
tellraw @s {"text":"LeaveDecay enabled.","color":"green"}
