tag @a add ldc.dimension_done
execute as @e[type=minecraft:marker,tag=ldc.queue] unless score @s ldc.runtime = #generation ldc.config run function leafdecay:queue/discard
scoreboard players add @e[type=minecraft:marker,tag=ldc.seed] ldc.age 1
tag @e[type=minecraft:marker,tag=ldc.frontier] add ldc.batch
execute as @e[type=minecraft:marker,tag=ldc.seed] if score @s ldc.age >= #delay ldc.config run tag @s add ldc.batch
execute if score #remaining ldc.runtime matches 1.. if entity @e[type=minecraft:marker,tag=ldc.batch] run function leafdecay:queue/drain
