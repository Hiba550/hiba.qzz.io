scoreboard players remove #active ldc.runtime 1
execute if score #active ldc.runtime matches ..-1 run scoreboard players set #active ldc.runtime 0
execute positioned ~-1 ~-1 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~-1 ~-1 ~0 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~-1 ~-1 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~-1 ~0 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~-1 ~0 ~0 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~-1 ~0 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~-1 ~1 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~-1 ~1 ~0 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~-1 ~1 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~0 ~-1 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~0 ~-1 ~0 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~0 ~-1 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~0 ~0 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~0 ~0 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~0 ~1 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~0 ~1 ~0 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~0 ~1 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~1 ~-1 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~1 ~-1 ~0 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~1 ~-1 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~1 ~0 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~1 ~0 ~0 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~1 ~0 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~1 ~1 ~-1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~1 ~1 ~0 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
execute positioned ~1 ~1 ~1 if block ~ ~ ~ #minecraft:leaves[distance=7,persistent=false] if score #active ldc.runtime < #max ldc.config run function leafdecay:queue/claim
kill @s
