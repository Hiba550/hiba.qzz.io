tag @s add ldc.queue
tag @s add ldc.frontier
scoreboard players operation @s ldc.runtime = #generation ldc.config
scoreboard players add #active ldc.runtime 1
