scoreboard players remove #remaining ldc.runtime 1
execute as @e[type=minecraft:marker,tag=ldc.batch,limit=1,sort=arbitrary] at @s run function leafdecay:queue/process
execute if score #remaining ldc.runtime matches 1.. if entity @e[type=minecraft:marker,tag=ldc.batch] run function leafdecay:queue/drain
