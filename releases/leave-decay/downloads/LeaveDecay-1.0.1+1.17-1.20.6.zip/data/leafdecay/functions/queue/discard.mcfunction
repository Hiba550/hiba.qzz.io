scoreboard players remove #active ldc.runtime 1
execute if score #active ldc.runtime matches ..-1 run scoreboard players set #active ldc.runtime 0
kill @s
