loot spawn ~0.5 ~0.5 ~0.5 mine ~ ~ ~ minecraft:air
setblock ~ ~ ~ minecraft:air
summon minecraft:marker ~ ~ ~ {Tags:["ldc.queue","ldc.frontier","ldc.new"]}
scoreboard players operation @e[type=minecraft:marker,tag=ldc.new,distance=..0.1] ldc.runtime = #generation ldc.config
tag @e[type=minecraft:marker,tag=ldc.new,distance=..0.1] remove ldc.new
scoreboard players add #active ldc.runtime 1
