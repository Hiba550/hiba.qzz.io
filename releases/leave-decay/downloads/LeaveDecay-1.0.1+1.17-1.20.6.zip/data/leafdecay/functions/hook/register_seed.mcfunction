tag @s add ldc.queue
tag @s add ldc.seed
scoreboard players set @s ldc.age 0
scoreboard players operation @s ldc.runtime = #generation ldc.config
scoreboard players add #active ldc.runtime 1
