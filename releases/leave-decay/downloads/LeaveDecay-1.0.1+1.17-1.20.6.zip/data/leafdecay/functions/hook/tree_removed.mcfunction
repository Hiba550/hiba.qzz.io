scoreboard players add #hook_events ldc.runtime 1
scoreboard players operation #last_hook ldc.runtime = #clock ldc.runtime
execute if score #enabled ldc.config matches 1 if score #active ldc.runtime < #max ldc.config run function leafdecay:hook/enqueue
