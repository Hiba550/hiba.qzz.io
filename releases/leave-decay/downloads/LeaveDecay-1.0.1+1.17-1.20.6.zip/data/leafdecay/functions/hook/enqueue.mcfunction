summon minecraft:marker ~ ~ ~ {Tags:["ldc.queue","ldc.seed","ldc.new"]}
scoreboard players set @e[type=minecraft:marker,tag=ldc.new,distance=..0.1] ldc.age 0
scoreboard players operation @e[type=minecraft:marker,tag=ldc.new,distance=..0.1] ldc.runtime = #generation ldc.config
tag @e[type=minecraft:marker,tag=ldc.new,distance=..0.1] remove ldc.new
scoreboard players add #active ldc.runtime 1
