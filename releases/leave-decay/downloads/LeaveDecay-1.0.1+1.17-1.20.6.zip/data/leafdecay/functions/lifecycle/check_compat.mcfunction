scoreboard players set #compat ldc.runtime 0
execute if score #leafdecay_hook tvm.config matches 1 run scoreboard players set #compat ldc.runtime 1
execute if score #leafdecay_hook vmr.config matches 1 run scoreboard players set #compat ldc.runtime 1
execute if score #leafdecay_hook tvl.state matches 1 run scoreboard players set #compat ldc.runtime 1
execute if score #leafdecay_hook vml.state matches 1 run scoreboard players set #compat ldc.runtime 1
scoreboard players set #compat_checked ldc.runtime 1
execute if score #compat ldc.runtime matches 0 run tellraw @a [{"text":"LeaveDecay is not connected to a compatible TreeVeinMiner or VeinMiner build.","color":"red"},{"text":" Use a paired release; legacy 7.0.x builds do not contain the required hook.","color":"yellow"}]
