scoreboard players add #clock ldc.runtime 1
execute if score #compat_checked ldc.runtime matches 0 run scoreboard players add #compat_age ldc.runtime 1
execute if score #compat_checked ldc.runtime matches 0 if score #compat_age ldc.runtime matches 60.. run function leafdecay:lifecycle/check_compat
scoreboard players operation #remaining ldc.runtime = #budget ldc.config
tag @a remove ldc.dimension_done
execute if score #enabled ldc.config matches 1 as @a[tag=!ldc.dimension_done] at @s run function leafdecay:queue/tick_dimension
tag @a remove ldc.dimension_done
