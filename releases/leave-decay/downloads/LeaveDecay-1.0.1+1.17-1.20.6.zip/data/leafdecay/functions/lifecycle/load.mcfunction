scoreboard objectives add ldc.config dummy
scoreboard objectives add ldc.runtime dummy
scoreboard objectives add ldc.age dummy
execute unless score #enabled ldc.config matches 0..1 run scoreboard players set #enabled ldc.config 1
execute unless score #budget ldc.config matches 1..16 run scoreboard players set #budget ldc.config 6
execute unless score #max ldc.config matches 32..4096 run scoreboard players set #max ldc.config 2048
execute unless score #delay ldc.config matches 6..40 run scoreboard players set #delay ldc.config 10
execute unless score #generation ldc.config matches 0.. run scoreboard players set #generation ldc.config 1
execute unless score #active ldc.runtime matches 0.. run scoreboard players set #active ldc.runtime 0
execute unless score #clock ldc.runtime matches 0.. run scoreboard players set #clock ldc.runtime 0
scoreboard players set #compat ldc.runtime 0
scoreboard players set #compat_age ldc.runtime 0
scoreboard players set #compat_checked ldc.runtime 0
execute unless score #hook_events ldc.runtime matches 0.. run scoreboard players set #hook_events ldc.runtime 0
tellraw @a [{"text":"LeaveDecay ","color":"green"},{"text":"1.0.1","color":"white"},{"text":" loaded","color":"gray"}]
