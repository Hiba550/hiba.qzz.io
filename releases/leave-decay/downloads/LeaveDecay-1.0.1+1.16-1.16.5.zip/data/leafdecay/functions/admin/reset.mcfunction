scoreboard players add #generation ldc.config 1
scoreboard players set #active ldc.runtime 0
execute as @a at @s run kill @e[type=minecraft:area_effect_cloud,tag=ldc.queue]
tellraw @s {"text":"LeaveDecay pending cleanup cleared.","color":"yellow"}
