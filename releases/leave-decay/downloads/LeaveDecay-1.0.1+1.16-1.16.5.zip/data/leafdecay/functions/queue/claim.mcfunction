loot spawn ~0.5 ~0.5 ~0.5 mine ~ ~ ~ minecraft:air
setblock ~ ~ ~ minecraft:air
summon minecraft:area_effect_cloud ~ ~ ~ {Radius:0.5f,Duration:2147483647,WaitTime:2147483647,Tags:["ldc.queue","ldc.frontier","ldc.new"]}
scoreboard players operation @e[type=minecraft:area_effect_cloud,tag=ldc.new,distance=..0.1] ldc.runtime = #generation ldc.config
tag @e[type=minecraft:area_effect_cloud,tag=ldc.new,distance=..0.1] remove ldc.new
scoreboard players add #active ldc.runtime 1
