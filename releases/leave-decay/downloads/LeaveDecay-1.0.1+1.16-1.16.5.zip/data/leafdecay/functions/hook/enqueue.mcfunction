summon minecraft:area_effect_cloud ~ ~ ~ {Radius:0.5f,Duration:2147483647,WaitTime:2147483647,Tags:["ldc.queue","ldc.seed","ldc.new"]}
scoreboard players set @e[type=minecraft:area_effect_cloud,tag=ldc.new,distance=..0.1] ldc.age 0
scoreboard players operation @e[type=minecraft:area_effect_cloud,tag=ldc.new,distance=..0.1] ldc.runtime = #generation ldc.config
tag @e[type=minecraft:area_effect_cloud,tag=ldc.new,distance=..0.1] remove ldc.new
scoreboard players add #active ldc.runtime 1
