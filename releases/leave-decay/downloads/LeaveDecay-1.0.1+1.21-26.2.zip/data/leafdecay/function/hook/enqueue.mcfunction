execute summon minecraft:marker run function leafdecay:hook/register_seed
