loot spawn ~0.5 ~0.5 ~0.5 mine ~ ~ ~ minecraft:air
setblock ~ ~ ~ minecraft:air
execute summon minecraft:marker run function leafdecay:queue/register_frontier
